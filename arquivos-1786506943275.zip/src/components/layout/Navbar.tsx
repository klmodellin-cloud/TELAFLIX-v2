import { useEffect, useState } from 'react'
import { Link } from '@tanstack/react-router'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Heart, LogOut, User, Home, Search } from 'lucide-react'

export function Navbar() {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user))

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user || null)
    })

    return () => subscription.unsubscribe()
  }, [])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setUser(null)
  }

  return (
    <nav className="sticky top-0 z-50 bg-gradient-to-b from-slate-950/95 to-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition">
          <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            🎬 TelaFlixHD
          </span>
        </Link>

        {/* Center Menu */}
        <div className="hidden md:flex items-center gap-8">
          <Link to="/" className="text-gray-300 hover:text-white transition flex items-center gap-2">
            <Home className="w-4 h-4" /> Início
          </Link>
          <a href="#" className="text-gray-300 hover:text-white transition flex items-center gap-2">
            <Search className="w-4 h-4" /> Buscar
          </a>
        </div>

        {/* Auth */}
        <div className="flex items-center gap-4">
          {user ? (
            <>
              <Link to="/favorites">
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                  <Heart className="w-4 h-4" /> Favoritos
                </Button>
              </Link>

              <Button
                variant="ghost"
                size="sm"
                className="text-gray-300 hover:text-white"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4" /> Sair
              </Button>
            </>
          ) : (
            <Link to="/auth">
              <Button className="bg-purple-600 hover:bg-purple-700">
                <User className="w-4 h-4 mr-2" /> Entrar
              </Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  )
}
