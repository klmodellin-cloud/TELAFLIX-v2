import { createFileRoute } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/integrations/supabase/client'
import { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Play, Info, Heart, Search } from 'lucide-react'
import { Input } from '@/components/ui/input'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  const [user, setUser] = useState<any>(null)
  const [type, setType] = useState<'all' | 'movie' | 'series'>('all')
  const [genre, setGenre] = useState<string>('all')
  const [searchQuery, setSearchQuery] = useState('')

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user))
  }, [])

  const { data: content, isLoading } = useQuery({
    queryKey: ['content', type, genre, searchQuery],
    queryFn: async () => {
      let query = supabase.from('content').select('*')

      if (type !== 'all') query = query.eq('type', type)
      if (genre !== 'all') query = query.eq('genre', genre)
      if (searchQuery) {
        query = query.ilike('title', `%${searchQuery}%`)
      }

      const { data, error } = await query.order('rating', { ascending: false }).limit(50)
      if (error) throw error
      return data
    },
  })

  const { data: allContent } = useQuery({
    queryKey: ['allContent'],
    queryFn: async () => {
      const { data, error } = await supabase.from('content').select('*')
      if (error) throw error
      return data
    },
  })

  const genres = Array.from(
    new Set(allContent?.map(item => item.genre).filter(Boolean))
  ).sort()

  const heroContent = content?.[0]

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero Section */}
      {heroContent && (
        <div className="relative h-screen bg-cover bg-center overflow-hidden group">
          <img
            src={heroContent.backdrop_url}
            alt={heroContent.title}
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent"></div>

          <div className="relative z-10 flex flex-col justify-center h-full px-8 md:px-16 max-w-2xl">
            <Badge className="w-fit mb-4 bg-purple-600">{heroContent.type === 'movie' ? '🎬 Filme' : '📺 Série'}</Badge>
            <h1 className="text-6xl md:text-7xl font-bold text-white mb-4 drop-shadow-lg">
              {heroContent.title}
            </h1>
            <p className="text-lg text-gray-300 mb-6 line-clamp-3 drop-shadow">
              {heroContent.description}
            </p>

            <div className="flex gap-4 mb-8">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                <Play className="w-5 h-5 mr-2" /> Assistir Agora
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <Info className="w-5 h-5 mr-2" /> Mais Informações
              </Button>
            </div>

            <div className="flex gap-8 text-gray-300">
              <div>
                <span className="font-bold text-white">{heroContent.rating}</span>
                <span className="ml-1">⭐ Avaliação</span>
              </div>
              <div>
                <span className="font-bold text-white">{heroContent.year}</span>
                <span className="ml-1">Ano</span>
              </div>
              <div>
                <span className="font-bold text-white">{heroContent.genre}</span>
                <span className="ml-1">Gênero</span>
              </div>
            </div>
          </div>

          {/* Gradient overlay bottom */}
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-slate-950 to-transparent"></div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        {/* Search & Filters */}
        <div className="mb-12 space-y-6">
          <div className="relative">
            <Search className="absolute left-4 top-3.5 w-5 h-5 text-gray-500" />
            <Input
              placeholder="Buscar filmes, séries..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-12 py-3 bg-slate-800 border-slate-700 text-white placeholder:text-gray-500 text-lg"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Type Filter */}
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-3">Tipo</label>
              <div className="flex gap-2">
                {[
                  { label: 'Todos', value: 'all' },
                  { label: 'Filmes', value: 'movie' },
                  { label: 'Séries', value: 'series' },
                ].map(option => (
                  <Button
                    key={option.value}
                    onClick={() => setType(option.value as any)}
                    variant={type === option.value ? 'default' : 'outline'}
                    className="flex-1 text-sm"
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Genre Filter */}
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold text-gray-300 mb-3">Gênero</label>
              <select
                value={genre}
                onChange={e => setGenre(e.target.value)}
                className="w-full px-4 py-2 bg-slate-800 text-white border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 transition"
              >
                <option value="all">Todos os Gêneros</option>
                {genres.map(g => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <h2 className="text-2xl font-bold text-white mb-8">
          {searchQuery ? `Resultados para "${searchQuery}"` : 'Catálogo Completo'}
          <span className="text-gray-400 text-lg ml-3">({content?.length || 0})</span>
        </h2>

        {/* Content Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {[...Array(15)].map((_, i) => (
              <div
                key={i}
                className="bg-gradient-to-br from-slate-800 to-slate-900 h-80 rounded-lg animate-pulse"
              ></div>
            ))}
          </div>
        ) : content && content.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {content.map(item => (
              <ContentCard key={item.id} item={item} user={user} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-gray-400 text-xl">Nenhum conteúdo encontrado</p>
          </div>
        )}
      </div>
    </div>
  )
}

function ContentCard({ item, user }: { item: any; user: any }) {
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    if (!user) return

    supabase
      .from('favorites')
      .select('id')
      .eq('user_id', user.id)
      .eq('content_id', item.id)
      .single()
      .then(({ data }) => setIsFavorite(!!data))
  }, [item.id, user])

  const toggleFavorite = async () => {
    if (!user) return

    if (isFavorite) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('content_id', item.id)
    } else {
      await supabase
        .from('favorites')
        .insert([{ user_id: user.id, content_id: item.id }])
    }

    setIsFavorite(!isFavorite)
  }

  return (
    <Card className="bg-slate-800 border-slate-700 overflow-hidden group hover:shadow-2xl transition-all duration-300 hover:scale-110 cursor-pointer">
      <div className="relative h-64 overflow-hidden bg-slate-900">
        <img
          src={item.poster_url}
          alt={item.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />

        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-4">
          <div className="flex justify-end">
            {user && (
              <Button
                size="sm"
                variant="ghost"
                onClick={toggleFavorite}
                className={isFavorite ? 'text-red-500' : 'text-white'}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
              </Button>
            )}
          </div>

          <div className="space-y-2">
            <Button className="w-full bg-purple-600 hover:bg-purple-700 text-sm">
              <Play className="w-4 h-4 mr-1" /> Assistir
            </Button>
          </div>
        </div>

        {/* Badge */}
        <Badge className="absolute top-2 left-2 bg-purple-600/90">{item.type === 'movie' ? '🎬' : '📺'}</Badge>
      </div>

      <CardContent className="p-4 space-y-2">
        <h3 className="font-bold text-white text-sm line-clamp-2 group-hover:text-purple-400">
          {item.title}
        </h3>

        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400">{item.year}</span>
          <Badge variant="secondary" className="text-xs">{item.rating}⭐</Badge>
        </div>

        <Badge variant="outline" className="text-xs">{item.genre}</Badge>

        {item.type === 'series' && (
          <p className="text-xs text-gray-500">
            {item.seasons} temp • {item.episodes} ep
          </p>
        )}
      </CardContent>
    </Card>
  )
}
