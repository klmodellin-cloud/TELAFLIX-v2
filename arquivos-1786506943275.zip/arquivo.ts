import { createFileRoute } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/integrations/supabase/client'
import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Play, Heart, Share2, Star } from 'lucide-react'
import { Textarea } from '@/components/ui/textarea'

export const Route = createFileRoute('/content/$id')({
  component: ContentDetail,
})

function ContentDetail() {
  const { id } = Route.useParams()
  const [user, setUser] = useState<any>(null)
  const [rating, setRating] = useState(0)
  const [reviewText, setReviewText] = useState('')

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user))
  }, [])

  const { data: content } = useQuery({
    queryKey: ['content', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('content')
        .select('*')
        .eq('id', id)
        .single()

      if (error) throw error
      return data
    },
  })

  const { data: reviews } = useQuery({
    queryKey: ['reviews', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('reviews')
        .select('*, profiles(username, avatar_url)')
        .eq('content_id', id)
        .order('created_at', { ascending: false })

      if (error) throw error
      return data
    },
  })

  const handleSubmitReview = async () => {
    if (!user || rating === 0) return

    await supabase.from('reviews').upsert([
      {
        user_id: user.id,
        content_id: parseInt(id),
        rating,
        review_text: reviewText,
      },
    ])

    setRating(0)
    setReviewText('')
  }

  if (!content) return <div>Carregando...</div>

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <div
        className="relative h-96 bg-cover bg-center"
        style={{ backgroundImage: `url(${content.backdrop_url})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-slate-950"></div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 md:px-8 -mt-32 relative z-10 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Poster */}
          <div>
            <img
              src={content.poster_url}
              alt={content.title}
              className="w-full rounded-lg shadow-2xl"
            />
          </div>

          {/* Info */}
          <div className="md:col-span-2 space-y-6">
            <div>
              <Badge className="mb-3 bg-purple-600">{content.type === 'movie' ? 'Filme' : 'Série'}</Badge>
              <h1 className="text-5xl font-bold text-white mb-2">{content.title}</h1>
              <p className="text-gray-400">{content.year}</p>
            </div>

            <div className="flex gap-4">
              <div className="flex items-center">
                <Star className="w-5 h-5 text-yellow-400 fill-yellow-400 mr-2" />
                <span className="text-2xl font-bold text-white">{content.rating}</span>
                <span className="text-gray-400">/10</span>
              </div>
              <Badge variant="secondary">{content.genre}</Badge>
            </div>

            <p className="text-gray-300 text-lg leading-relaxed">{content.description}</p>

            {content.type === 'movie' && (
              <p className="text-gray-400">
                <span className="font-semibold">Duração:</span> {content.duration_minutes} minutos
              </p>
            )}

            {content.type === 'series' && (
              <p className="text-gray-400">
                <span className="font-semibold">Temporadas:</span> {content.seasons} | 
                <span className="font-semibold ml-4">Episódios:</span> {content.episodes}
              </p>
            )}

            <div className="flex gap-4 pt-4">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                <Play className="w-5 h-5 mr-2" /> Assistir Agora
              </Button>
              <Button size="lg" variant="outline" className="border-slate-700 text-white">
                <Heart className="w-5 h-5 mr-2" /> Favoritar
              </Button>
              <Button size="lg" variant="outline" className="border-slate-700 text-white">
                <Share2 className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Reviews */}
        <div className="mt-16 space-y-8">
          <h2 className="text-3xl font-bold text-white">Avaliações dos Usuários</h2>

          {user && (
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle>Sua Avaliação</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-300 mb-2 block">Nota</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(r => (
                      <Button
                        key={r}
                        onClick={() => setRating(r)}
                        variant={rating === r ? 'default' : 'outline'}
                        className="w-10 h-10 p-0"
                      >
                        {r}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-300 mb-2 block">Comentário (opcional)</label>
                  <Textarea
                    placeholder="Compartilhe sua opinião..."
                    value={reviewText}
                    onChange={e => setReviewText(e.target.value)}
                    className="bg-slate-900 border-slate-700"
                  />
                </div>

                <Button onClick={handleSubmitReview} disabled={rating === 0} className="w-full bg-purple-600">
                  Publicar Avaliação
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="space-y-4">
            {reviews?.map(review => (
              <Card key={review.id} className="bg-slate-800 border-slate-700">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="font-semibold text-white">{review.profiles?.username}</p>
                      <div className="flex gap-1">
                        {[...Array(10)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'}`}
                          />
                        ))}
                      </div>
                    </div>
                    <Badge>{review.rating}</Badge>
                  </div>
                  <p className="text-gray-400">{review.review_text}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
